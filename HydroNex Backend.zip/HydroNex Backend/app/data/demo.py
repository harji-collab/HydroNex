from math import cos, sin

MONTHS = [
    "Oct 23","Nov 23","Dec 23","Jan 24","Feb 24","Mar 24",
    "Apr 24","May 24","Jun 24","Jul 24","Aug 24","Sep 24",
    "Oct 24","Nov 24","Dec 24","Jan 25","Feb 25","Mar 25",
    "Apr 25","May 25","Jun 25","Jul 25","Aug 25","Sep 25"
]

WATERBODIES = [
    {"id":"suryanagar","name":"Suryanagar Reservoir","short":"Suryanagar","region":"Central Basin","lat":21.42,"lon":78.98,"currentArea":2.91,"historicalAverageArea":4.24,"areaChangePercent":-31.4,"rainfallAnomalyPercent":-18.2,"responseScore":0.74,"vulnerabilityScore":78,"vulnerabilityLevel":"High","trend":"Declining","lastAnalyzed":"30 Sep 2026, 08:42 IST","color":"#ff6f78","geometry":None,"center":[21.42,78.98]},
    {"id":"neelam","name":"Neelam Wetland","short":"Neelam","region":"Eastern Delta","lat":22.68,"lon":87.26,"currentArea":6.42,"historicalAverageArea":6.1,"areaChangePercent":5.2,"rainfallAnomalyPercent":11.6,"responseScore":0.58,"vulnerabilityScore":44,"vulnerabilityLevel":"Moderate","trend":"Stable","lastAnalyzed":"30 Sep 2026, 08:37 IST","color":"#f2b66a","geometry":None,"center":[22.68,87.26]},
    {"id":"aranya","name":"Aranya Lake","short":"Aranya","region":"Northern Plateau","lat":27.41,"lon":80.12,"currentArea":8.82,"historicalAverageArea":8.55,"areaChangePercent":3.1,"rainfallAnomalyPercent":8.4,"responseScore":0.39,"vulnerabilityScore":24,"vulnerabilityLevel":"Low","trend":"Recovering","lastAnalyzed":"30 Sep 2026, 08:31 IST","color":"#55d69a","geometry":None,"center":[27.41,80.12]},
    {"id":"devika","name":"Devika Basin","short":"Devika","region":"Southern Coast","lat":15.13,"lon":76.51,"currentArea":1.84,"historicalAverageArea":2.86,"areaChangePercent":-35.7,"rainfallAnomalyPercent":-22.8,"responseScore":0.81,"vulnerabilityScore":86,"vulnerabilityLevel":"Critical","trend":"Declining","lastAnalyzed":"30 Sep 2026, 08:18 IST","color":"#ff5464","geometry":None,"center":[15.13,76.51]},
    {"id":"kaveri","name":"Kaveri Tank Cluster","short":"Kaveri","region":"Southern Coast","lat":12.91,"lon":77.59,"currentArea":4.76,"historicalAverageArea":5.12,"areaChangePercent":-7.0,"rainfallAnomalyPercent":-4.1,"responseScore":0.66,"vulnerabilityScore":57,"vulnerabilityLevel":"Moderate","trend":"Declining","lastAnalyzed":"30 Sep 2026, 08:11 IST","color":"#f2b66a","geometry":None,"center":[12.91,77.59]},
    {"id":"pavana","name":"Pavana Backwater","short":"Pavana","region":"Western Ghats","lat":18.72,"lon":73.76,"currentArea":9.34,"historicalAverageArea":8.72,"areaChangePercent":7.1,"rainfallAnomalyPercent":16.4,"responseScore":0.47,"vulnerabilityScore":31,"vulnerabilityLevel":"Low","trend":"Recovering","lastAnalyzed":"30 Sep 2026, 08:06 IST","color":"#55d69a","geometry":None,"center":[18.72,73.76]},
    {"id":"renga","name":"Renga Floodplain","short":"Renga","region":"Eastern Delta","lat":24.6,"lon":85.12,"currentArea":3.68,"historicalAverageArea":4.21,"areaChangePercent":-12.6,"rainfallAnomalyPercent":-9.7,"responseScore":0.69,"vulnerabilityScore":63,"vulnerabilityLevel":"High","trend":"Declining","lastAnalyzed":"30 Sep 2026, 07:59 IST","color":"#ff6f78","geometry":None,"center":[24.6,85.12]},
    {"id":"tansa","name":"Tansa Lake","short":"Tansa","region":"Western Ghats","lat":19.74,"lon":72.96,"currentArea":7.11,"historicalAverageArea":6.88,"areaChangePercent":3.4,"rainfallAnomalyPercent":5.2,"responseScore":0.42,"vulnerabilityScore":27,"vulnerabilityLevel":"Low","trend":"Stable","lastAnalyzed":"30 Sep 2026, 07:53 IST","color":"#55d69a","geometry":None,"center":[19.74,72.96]},
]

def water_extent(w):
    base = w["historicalAverageArea"]
    drift = (w["currentArea"] - base) / 24
    amplitude = 0.34
    out = []
    for i, date in enumerate(MONTHS):
        area = round(base + drift*i + sin(i/2.1)*amplitude, 2)
        out.append({"date": date, "area": area, "baselineArea": round(base + amplitude*0.15, 2)})
    return out

def rainfall(w, index):
    base = 88 + index*5
    swing = 28 + index*2
    out = []
    for i, date in enumerate(MONTHS):
        value = base + cos((i+index)/1.9)*swing + (swing*0.32 if i % 5 == 0 else 0)
        value = round(value, 1)
        out.append({"date": date, "rainfall": value, "baselineRainfall": base,
                    "anomaly": round(((value-base)/base)*100, 1)})
    return out

WATER_EXTENT = {w["id"]: water_extent(w) for w in WATERBODIES}
RAINFALL = {w["id"]: rainfall(w, i) for i, w in enumerate(WATERBODIES)}

RESPONSE = {
    w["id"]: {
        "waterbodyId": w["id"],
        "responseScore": w["responseScore"],
        "associationMetric": round(w["responseScore"] - 0.08, 2),
        "lagEstimate": "2–3 months" if w["responseScore"] > 0.7 else "1–2 months",
        "trend": "Improving" if w["trend"] == "Recovering" else "Under pressure",
        "rainfallAnomaly": w["rainfallAnomalyPercent"],
        "waterAreaChange": w["areaChangePercent"],
        "analysisPeriod": "Oct 2023 – Sep 2026",
    } for w in WATERBODIES
}

VULNERABILITIES = {
    w["id"]: {
        "score": w["vulnerabilityScore"],
        "level": w["vulnerabilityLevel"],
        "components": {
            "rainfallAnomaly": round(abs(w["rainfallAnomalyPercent"]) * 0.9),
            "waterAreaChange": round(abs(w["areaChangePercent"]) * 0.72),
            "historicalTrend": 17 if w["trend"] == "Declining" else (10 if w["trend"] == "Stable" else 6),
            "response": round(w["responseScore"] * 16),
        },
        "explanation": (
            "Multiple indicators are concurrently outside the demonstration baseline range."
            if w["vulnerabilityLevel"] == "Critical"
            else "The score combines observed anomalies and historical indicators for prioritization."
        ),
    } for w in WATERBODIES
}

INSIGHTS = [
    {"id":"i1","type":"Priority waterbody","title":"Decline signal requires a closer look","location":"Suryanagar Reservoir · Central Basin","severity":"High","evidence":["Water area ↓ 31.4%","Rainfall anomaly ↓ 18.2%","Response score 0.74"],"recommendation":"Prioritize monitoring and conservation assessment.","waterbodyId":"suryanagar"},
    {"id":"i2","type":"Emerging water stress","title":"Compounding stress in southern basin","location":"Devika Basin · Southern Coast","severity":"Critical","evidence":["Water area ↓ 35.7%","Rainfall anomaly ↓ 22.8%","Response score 0.81"],"recommendation":"Review seasonal recharge and intervention options.","waterbodyId":"devika"},
    {"id":"i3","type":"Rainfall-sensitive","title":"High response indicator observed","location":"Renga Floodplain · Eastern Delta","severity":"High","evidence":["Association metric 0.61","Lag estimate 2–3 months","Area trend: declining"],"recommendation":"Keep rainfall-response monitoring active through the next cycle.","waterbodyId":"renga"},
    {"id":"i4","type":"Recent area decline","title":"Moderate loss across tank cluster","location":"Kaveri Tank Cluster · Southern Coast","severity":"Moderate","evidence":["Water area ↓ 7.0%","Rainfall anomaly ↓ 4.1%","Response score 0.66"],"recommendation":"Compare observed extent with local conservation activity data.","waterbodyId":"kaveri"},
]

SYSTEM_STATUS = [
    {"label":"Google Earth Engine","value":"Not connected","detail":"Backend adapter is ready; live credentials have not been configured.","state":"demo"},
    {"label":"Sentinel-2","value":"Adapter ready","detail":"Surface-water processing endpoint contract is ready.","state":"connected"},
    {"label":"CHIRPS rainfall","value":"Adapter ready","detail":"Rainfall time-series endpoint contract is ready.","state":"connected"},
    {"label":"Backend API","value":"Connected","detail":"FastAPI is serving this dashboard.","state":"connected"},
    {"label":"Last successful analysis","value":"Demo snapshot","detail":"Live Earth Engine analysis will replace this after configuration.","state":"demo"},
    {"label":"Data freshness","value":"Demo snapshot","detail":"Not a live Earth Engine result yet.","state":"demo"},
]

REGIONS = ["All regions"] + sorted({w["region"] for w in WATERBODIES})

KPIS = {
    "monitored": len(WATERBODIES),
    "high": sum(w["vulnerabilityLevel"] in ["High","Critical"] for w in WATERBODIES),
    "rainfall": -7.3,
    "areaChange": -9.8,
    "strongResponse": sum(w["responseScore"] >= 0.7 for w in WATERBODIES),
}

OVERVIEW_AREA_TREND = [4.7,4.5,4.42,4.26,4.12,4.3,4.48,4.22,4.05,3.98,3.9,3.84,3.71,3.62,3.58,3.46,3.5,3.4]
OVERVIEW_RAIN_TREND = [112,98,124,93,101,86,75,91,84,69,78,88,64,82,74,68,79,61]
