from __future__ import annotations

from datetime import date, datetime, timedelta
from statistics import mean
from math import sqrt
import threading

from app.gee.client import earth_engine_ready
from app.gee.water import get_monthly_water_extent
from app.gee.rainfall import get_monthly_rainfall

CHEMBARAMBAKKAM = {
    "id": "chembarambakkam",
    "name": "Chembarambakkam Lake",
    "short": "Chembarambakkam",
    "region": "Chennai Basin",
    "lat": 13.01158,
    "lon": 80.06063,
    "color": "#5ce1e6",
    "geometry": None,
    "center": [400, 220],
}

_cache: dict | None = None
_cache_lock = threading.Lock()


def _month_ranges(count: int = 36):
    today = date.today()
    first_current = today.replace(day=1)
    # We intentionally stop at the previous complete month.
    months = []
    cursor = first_current
    for _ in range(count):
        end = cursor
        prev_month_last = end - timedelta(days=1)
        start = prev_month_last.replace(day=1)
        label = start.strftime("%b %y")
        months.append((start, end, label))
        cursor = start
    return list(reversed(months))


def _pearson(a: list[float], b: list[float]) -> float:
    n = min(len(a), len(b))
    if n < 3:
        return 0.0
    a = a[:n]
    b = b[:n]
    ma, mb = mean(a), mean(b)
    num = sum((x - ma) * (y - mb) for x, y in zip(a, b))
    den_a = sqrt(sum((x - ma) ** 2 for x in a))
    den_b = sqrt(sum((y - mb) ** 2 for y in b))
    if den_a == 0 or den_b == 0:
        return 0.0
    return num / (den_a * den_b)


def _slope(values: list[float]) -> float:
    n = len(values)
    if n < 2:
        return 0.0
    x_mean = (n - 1) / 2
    y_mean = mean(values)
    num = sum((i - x_mean) * (y - y_mean) for i, y in enumerate(values))
    den = sum((i - x_mean) ** 2 for i in range(n))
    return num / den if den else 0.0


def _level(score: float) -> str:
    if score >= 75:
        return "Critical"
    if score >= 55:
        return "High"
    if score >= 30:
        return "Moderate"
    return "Low"


def _color(level: str) -> str:
    return {
        "Critical": "#ff5464",
        "High": "#ff6f78",
        "Moderate": "#f2b66a",
        "Low": "#55d69a",
    }[level]


def _build_live_analysis() -> dict:
    months = _month_ranges(36)
    water = get_monthly_water_extent(months)
    rain = get_monthly_rainfall(months)

    water_by_date = {item["date"]: item["area"] for item in water}
    rain_by_date = {item["date"]: item["rainfall"] for item in rain}
    common = [label for _, _, label in months if label in water_by_date and label in rain_by_date]

    if len(common) < 6:
        raise RuntimeError("Not enough overlapping Sentinel-2 and CHIRPS observations for analysis")

    areas = [water_by_date[x] for x in common]
    rainfall = [rain_by_date[x] for x in common]
    baseline_area = mean(areas)
    baseline_rain = mean(rainfall)
    current_area = areas[-1]
    current_rain = rainfall[-1]

    area_change = ((current_area - baseline_area) / baseline_area * 100) if baseline_area else 0.0
    rain_anomaly = ((current_rain - baseline_rain) / baseline_rain * 100) if baseline_rain else 0.0

    lag_results = []
    for lag in (0, 1, 2):
        if lag == 0:
            r = _pearson(rainfall, areas)
        else:
            r = _pearson(rainfall[:-lag], areas[lag:])
        lag_results.append((lag, r))
    lag, association = max(lag_results, key=lambda item: abs(item[1]))
    response_score = abs(association)

    slope = _slope(areas)
    if slope < -0.01:
        trend = "Declining"
    elif slope > 0.01:
        trend = "Recovering"
    else:
        trend = "Stable"

    rainfall_component = min(25.0, max(0.0, -rain_anomaly * 0.5))
    area_component = min(35.0, max(0.0, -area_change * 0.7))
    trend_component = min(20.0, max(0.0, -slope / max(baseline_area, 0.001) * 100 * 8))
    response_component = response_score * 20.0
    vulnerability_score = round(min(100.0, rainfall_component + area_component + trend_component + response_component), 1)
    level = _level(vulnerability_score)

    extent = []
    for label in common:
        extent.append({
            "date": label,
            "area": round(water_by_date[label], 3),
            "baselineArea": round(baseline_area, 3),
        })

    rainfall_points = []
    for label in common:
        value = rain_by_date[label]
        rainfall_points.append({
            "date": label,
            "rainfall": round(value, 2),
            "baselineRainfall": round(baseline_rain, 2),
            "anomaly": round((value - baseline_rain) / baseline_rain * 100, 1) if baseline_rain else 0,
        })

    lag_text = "same month" if lag == 0 else f"{lag} month" + ("" if lag == 1 else "s")
    response_trend = "Improving" if trend == "Recovering" else "Under pressure" if trend == "Declining" else "Stable"

    waterbody = {
        **CHEMBARAMBAKKAM,
        "currentArea": round(current_area, 3),
        "historicalAverageArea": round(baseline_area, 3),
        "areaChangePercent": round(area_change, 1),
        "rainfallAnomalyPercent": round(rain_anomaly, 1),
        "responseScore": round(response_score, 2),
        "vulnerabilityScore": vulnerability_score,
        "vulnerabilityLevel": level,
        "trend": trend,
        "lastAnalyzed": datetime.now().strftime("%d %b %Y, %H:%M IST"),
        "color": _color(level),
    }

    response = {
        "waterbodyId": CHEMBARAMBAKKAM["id"],
        "responseScore": round(response_score, 2),
        "associationMetric": round(association, 2),
        "lagEstimate": lag_text,
        "trend": response_trend,
        "rainfallAnomaly": round(rain_anomaly, 1),
        "waterAreaChange": round(area_change, 1),
        "analysisPeriod": f"{common[0]} – {common[-1]}",
    }

    vulnerability = {
        "score": vulnerability_score,
        "level": level,
        "components": {
            "rainfallAnomaly": round(rainfall_component),
            "waterAreaChange": round(area_component),
            "historicalTrend": round(trend_component),
            "response": round(response_component),
        },
        "explanation": "Project-defined score combining rainfall anomaly, water-area change, historical trend and rainfall–water association. It is a prioritization indicator, not a causal prediction.",
    }

    insights = [{
        "id": "chembarambakkam-live",
        "type": "Live waterbody analysis",
        "title": f"{trend} surface-water signal",
        "location": "Chembarambakkam Lake · Chennai Basin",
        "severity": level,
        "evidence": [
            f"Water area {area_change:+.1f}% vs 36-month baseline",
            f"Rainfall anomaly {rain_anomaly:+.1f}% vs analysis-period baseline",
            f"Rainfall–water association {association:+.2f} with {lag_text} lag",
        ],
        "recommendation": "Use the observed response signal to prioritize closer monitoring and compare it with local hydrological or operational data.",
        "waterbodyId": CHEMBARAMBAKKAM["id"],
    }]

    area_trend = [round(x, 3) for x in areas[-18:]]
    rain_trend = [round(x, 2) for x in rainfall[-18:]]

    return {
        "waterbodies": [waterbody],
        "extent": {CHEMBARAMBAKKAM["id"]: extent},
        "rainfall": {CHEMBARAMBAKKAM["id"]: rainfall_points},
        "response": {CHEMBARAMBAKKAM["id"]: response},
        "vulnerability": {CHEMBARAMBAKKAM["id"]: vulnerability},
        "insights": insights,
        "signals": {
            "kpis": {
                "monitored": 1,
                "high": 1 if level in ("High", "Critical") else 0,
                "rainfall": round(rain_anomaly, 1),
                "areaChange": round(area_change, 1),
                "strongResponse": 1 if response_score >= 0.7 else 0,
            },
            "areaTrend": area_trend,
            "rainTrend": rain_trend,
        },
    }


class HydroNexEngine:
    def _live(self) -> dict:
        global _cache
        with _cache_lock:
            if _cache is None:
                _cache = _build_live_analysis()
            return _cache

    def get_regions(self):
        return ["All regions", "Chennai Basin"]

    def get_waterbodies(self):
        return self._live()["waterbodies"]

    def get_waterbody(self, waterbody_id: str):
        return next((w for w in self._live()["waterbodies"] if w["id"] == waterbody_id), None)

    def get_extent(self, waterbody_id: str):
        return self._live()["extent"].get(waterbody_id)

    def get_rainfall(self, waterbody_id: str):
        return self._live()["rainfall"].get(waterbody_id)

    def get_response(self, waterbody_id: str):
        return self._live()["response"].get(waterbody_id)

    def get_vulnerability(self, waterbody_id: str):
        return self._live()["vulnerability"].get(waterbody_id)

    def get_insights(self):
        return self._live()["insights"]

    def get_status(self):
        ready = earth_engine_ready()
        return [
            {"label": "Google Earth Engine", "value": "Connected" if ready else "Unavailable", "detail": "Live Earth Engine project is initialized." if ready else "Check GEE_PROJECT_ID and Earth Engine authentication.", "state": "connected" if ready else "error"},
            {"label": "Sentinel-2", "value": "Live", "detail": "Sentinel-2 SR imagery is used for MNDWI surface-water extraction.", "state": "connected"},
            {"label": "CHIRPS rainfall", "value": "Live", "detail": "CHIRPS daily precipitation is aggregated to monthly rainfall.", "state": "connected"},
            {"label": "Backend API", "value": "Connected", "detail": "FastAPI is serving the dashboard.", "state": "connected"},
            {"label": "Study waterbody", "value": "Chembarambakkam Lake", "detail": "First live HydroNex study site.", "state": "connected"},
            {"label": "Data freshness", "value": "Previous complete month", "detail": "Monthly analysis intentionally excludes the current incomplete month.", "state": "connected"},
        ]

    def get_overview(self):
        return self._live()["signals"]


engine = HydroNexEngine()
