from fastapi import APIRouter, HTTPException
from app.analysis.engine import engine

router = APIRouter(prefix="/api")

@router.get("/regions")
def regions():
    return engine.get_regions()

@router.get("/waterbodies")
def waterbodies():
    return engine.get_waterbodies()

@router.get("/waterbodies/{waterbody_id}")
def waterbody(waterbody_id: str):
    result = engine.get_waterbody(waterbody_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Waterbody not found")
    return result

@router.get("/waterbodies/{waterbody_id}/water-extent")
def water_extent(waterbody_id: str):
    result = engine.get_extent(waterbody_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Water extent not found")
    return result

@router.get("/waterbodies/{waterbody_id}/rainfall")
def rainfall(waterbody_id: str):
    result = engine.get_rainfall(waterbody_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Rainfall data not found")
    return result

@router.get("/waterbodies/{waterbody_id}/response")
def response(waterbody_id: str):
    result = engine.get_response(waterbody_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Response analysis not found")
    return result

@router.get("/waterbodies/{waterbody_id}/vulnerability")
def vulnerability(waterbody_id: str):
    result = engine.get_vulnerability(waterbody_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Vulnerability analysis not found")
    return result

@router.get("/insights")
def insights():
    return engine.get_insights()

@router.get("/analysis/status")
def analysis_status():
    return engine.get_status()

@router.get("/overview/signals")
def overview_signals():
    return engine.get_overview()
