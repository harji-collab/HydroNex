from typing import Any
from pydantic import BaseModel, Field

class Waterbody(BaseModel):
    id: str
    name: str
    short: str
    region: str
    lat: float
    lon: float
    currentArea: float
    historicalAverageArea: float
    areaChangePercent: float
    rainfallAnomalyPercent: float
    responseScore: float
    vulnerabilityScore: float
    vulnerabilityLevel: str
    trend: str
    lastAnalyzed: str
    color: str
    geometry: str | None = None
    center: list[float] | None = None

class WaterExtentPoint(BaseModel):
    date: str
    area: float
    baselineArea: float

class RainfallPoint(BaseModel):
    date: str
    rainfall: float
    baselineRainfall: float
    anomaly: float

class ResponseAnalysis(BaseModel):
    waterbodyId: str
    responseScore: float
    associationMetric: float
    lagEstimate: str
    trend: str
    rainfallAnomaly: float
    waterAreaChange: float
    analysisPeriod: str

class VulnerabilityComponents(BaseModel):
    rainfallAnomaly: int
    waterAreaChange: int
    historicalTrend: int
    response: int

class Vulnerability(BaseModel):
    score: float
    level: str
    components: VulnerabilityComponents
    explanation: str

class Insight(BaseModel):
    id: str
    type: str
    title: str
    location: str
    severity: str
    evidence: list[str]
    recommendation: str
    waterbodyId: str

class StatusItem(BaseModel):
    label: str
    value: str
    detail: str
    state: str

class OverviewSignals(BaseModel):
    kpis: dict[str, Any]
    areaTrend: list[float]
    rainTrend: list[float]

class HealthResponse(BaseModel):
    status: str
    service: str
    demoData: bool
    version: str
