import ee
from app.config import settings

_initialized = False


def initialize_earth_engine() -> None:
    """Initialize Earth Engine once for the FastAPI process."""
    global _initialized
    if _initialized:
        return

    if not settings.gee_project_id:
        raise RuntimeError("GEE_PROJECT_ID is not configured in .env")

    ee.Initialize(project=settings.gee_project_id)
    _initialized = True


def earth_engine_ready() -> bool:
    try:
        initialize_earth_engine()
        ee.Number(1).getInfo()
        return True
    except Exception:
        return False
