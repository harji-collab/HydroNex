from __future__ import annotations

from datetime import date
import ee

from app.gee.client import initialize_earth_engine

# Approximate study envelope around Chembarambakkam Lake.
# The stable JRC water-occurrence mask inside this envelope prevents nearby
# land from being counted as part of the Sentinel-2 lake measurement.
LAKE_BBOX = ee.Geometry.Rectangle(
    [80.00, 12.98, 80.09, 13.045],
    geodesic=False,
)


def _mask_clouds(image: ee.Image) -> ee.Image:
    qa = image.select("QA60")
    cloud = 1 << 10
    cirrus = 1 << 11
    mask = qa.bitwiseAnd(cloud).eq(0).And(qa.bitwiseAnd(cirrus).eq(0))
    return image.updateMask(mask).divide(10000)


def _jrc_footprint() -> ee.Image:
    # JRC occurrence is a long-term historical water-frequency layer.
    # >=25% is used here as a stable lake-footprint constraint.
    occurrence = ee.Image("JRC/GSW1_4/GlobalSurfaceWater").select("occurrence")
    return occurrence.gte(25)


def _monthly_water_area(start: date, end: date) -> float | None:
    initialize_earth_engine()

    collection = (
        ee.ImageCollection("COPERNICUS/S2_SR_HARMONIZED")
        .filterDate(str(start), str(end))
        .filterBounds(LAKE_BBOX)
        .filter(ee.Filter.lt("CLOUDY_PIXEL_PERCENTAGE", 60))
        .map(_mask_clouds)
    )

    count = collection.size().getInfo()
    if not count:
        return None

    composite = collection.median()
    mndwi = composite.normalizedDifference(["B3", "B11"])
    water = mndwi.gt(0.10).And(_jrc_footprint())

    area = (
        ee.Image.pixelArea()
        .updateMask(water)
        .reduceRegion(
            reducer=ee.Reducer.sum(),
            geometry=LAKE_BBOX,
            scale=20,
            maxPixels=100_000_000,
            bestEffort=True,
        )
        .get("area")
    )

    value = area.getInfo()
    return None if value is None else round(float(value) / 1_000_000, 3)


def get_monthly_water_extent(months: list[tuple[date, date, str]]) -> list[dict]:
    return [
        {
            "date": label,
            "area": area,
        }
        for start, end, label in months
        if (area := _monthly_water_area(start, end)) is not None
    ]
