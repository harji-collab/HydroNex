from __future__ import annotations

from datetime import date
import ee

from app.gee.client import initialize_earth_engine
from app.gee.water import LAKE_BBOX


def _monthly_rainfall(start: date, end: date) -> float | None:
    initialize_earth_engine()

    collection = (
        ee.ImageCollection("UCSB-CHG/CHIRPS/DAILY")
        .filterDate(str(start), str(end))
        .filterBounds(LAKE_BBOX)
        .select("precipitation")
    )

    count = collection.size().getInfo()
    if not count:
        return None

    total = collection.sum()
    rainfall = total.reduceRegion(
        reducer=ee.Reducer.mean(),
        geometry=LAKE_BBOX,
        scale=5566,
        maxPixels=100_000,
        bestEffort=True,
    ).get("precipitation")

    value = rainfall.getInfo()
    return None if value is None else round(float(value), 2)


def get_monthly_rainfall(months: list[tuple[date, date, str]]) -> list[dict]:
    return [
        {
            "date": label,
            "rainfall": rainfall,
        }
        for start, end, label in months
        if (rainfall := _monthly_rainfall(start, end)) is not None
    ]
