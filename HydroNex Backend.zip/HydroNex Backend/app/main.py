from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings, cors_origin_list
from app.api.routes import router

app = FastAPI(
    title="HydroNex API",
    description="Geospatial intelligence backend for rainfall–surface water response analysis.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origin_list(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

@app.get("/")
def root():
    return {
        "service": "HydroNex API",
        "status": "online",
        "version": "0.1.0",
        "next_phase": "Google Earth Engine + Sentinel-2 + CHIRPS integration",
    }

@app.get("/health")
def health():
    return {
        "status": "healthy",
        "service": "hydronex-backend",
        "demoData": settings.demo_data,
        "version": "0.1.0",
    }
