from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    hydronex_env: str = "development"
    cors_origins: str = "http://localhost:3000"
    demo_data: bool = True
    gee_project_id: str = ""
    gee_service_account_json: str = ""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

settings = Settings()

def cors_origin_list() -> list[str]:
    return [item.strip() for item in settings.cors_origins.split(",") if item.strip()]
