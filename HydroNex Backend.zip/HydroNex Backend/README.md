# HydroNex Backend — Phase 2 Live GEE

This version connects the existing HydroNex FastAPI contract to Google Earth Engine for a first real study site: Chembarambakkam Lake.

## Live data pipeline

- Sentinel-2 SR Harmonized for monthly surface-water extraction
- QA60 cloud/cirrus masking
- MNDWI water detection
- JRC Global Surface Water occurrence mask as a stable lake-footprint constraint
- CHIRPS daily rainfall aggregated to monthly totals
- 36 complete monthly observations
- Rainfall/water association with 0–2 month lag testing
- Project-defined vulnerability prioritization score

## Configure

Create `.env` beside `requirements.txt`:

```env
HYDRONEX_ENV=development
CORS_ORIGINS=http://localhost:3000,http://localhost:5173
DEMO_DATA=false
GEE_PROJECT_ID=YOUR_GOOGLE_CLOUD_PROJECT_ID
```

Authenticate Earth Engine once in the same Python environment:

```powershell
python -c "import ee; ee.Authenticate(auth_mode='localhost')"
python -c "import ee; ee.Initialize(project='YOUR_GOOGLE_CLOUD_PROJECT_ID'); print(ee.String('HYDRONEX EARTH ENGINE CONNECTED').getInfo())"
```

## Run

```powershell
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## First live API

Open:

- http://localhost:8000/api/waterbodies
- http://localhost:8000/api/waterbodies/chembarambakkam/water-extent
- http://localhost:8000/api/waterbodies/chembarambakkam/rainfall
- http://localhost:8000/api/waterbodies/chembarambakkam/response
- http://localhost:8000/api/waterbodies/chembarambakkam/vulnerability

The first live analysis may take some time because Earth Engine is processing monthly satellite composites. The engine caches the result in memory for the running API process.

## Interpretation

The rainfall-water association is descriptive. It is not causal proof. The vulnerability score is a HydroNex project-defined prioritization indicator, not an official government index.
